var gulp = require("gulp");

var scss = require('gulp-sass');
var cssnano = require('gulp-cssnano');
//因为我用的是scss,所以这里注册任务写成了scss;
gulp.task('scss',function(){
    gulp.src('css/**/*.scss')
    .pipe(scss())
    .pipe(cssnano())
    .pipe(gulp.dest('dist/css'))
});

var htmlmin = require('gulp-htmlmin');
gulp.task('html',function(){
    gulp.src('html/**/*.html')
    .pipe(htmlmin({
        collapseWhitespace : true,
        removeComments : true
    }))
    //最后把你建立的html文件压缩到自动创建的dist文件里;
    .pipe(gulp.dest('dist/html'))
})


var imagemin = require('gulp-imagemin');
var cache = require('gulp-cache');
gulp.task('image',function(){
    gulp.src('img/*.{jpg,pnp,gif}')//要处理的图片目录为img目录下的所有的.jpg .png .gif 格式的图片;
    .pipe(cache(imagemin({
        progressive : true,//是否渐进的优化
        svgoPlugins : [{removeViewBox:false}],//svgo插件是否删除幻灯片
        interlaced : true //是否各行扫描
    })))
    .pipe(gulp.dest('dist/img'))
});


var uglify = require('gulp-uglify');
gulp.task('js',function(){
    gulp.src('js/*.js')
    .pipe(uglify())
    .pipe(gulp.dest('dist/js'))
});

gulp.task('watch',['scss','js','html','image'],function(){
    gulp.watch('css/**/*.scss',['scss']);
    gulp.watch('js/**/*.js',['js']);
    gulp.watch('img/**/*.*',['image']);
    gulp.watch('html/**/*.html',['html']);
})

gulp.task("default",["watch","html","scss","image","js"],function(){
    gulp.start("watch","html","scss","image","js")
})

